package com.test.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import junit.framework.Assert;

@SpringBootTest
@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
public class ShortnerURLControllerTest {

	@Autowired
	ShortnerURLController shortnerURLController;

	private String shortURLSample;
	private String longURL;
	String longURLSample = "abcdfljdslfjdsklfdsfdsfdsfdsfdfdsfdsfjldf";

	@Test
	public void getShortnerURL() {
	    shortURLSample = shortnerURLController.getShortnerURL(longURLSample);
		longURL = shortnerURLController.getLongerURL(shortURLSample);
		Assert.assertEquals(longURL, longURLSample);
	}

	@Test
	public void getLongURL() {
		String shortURL= shortnerURLController.getShortnerURL(longURLSample);
		Assert.assertEquals(shortURL, shortURLSample);
	}

}
