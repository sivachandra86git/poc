package com.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.test.dao.ShortnerURLRepository;
import com.test.model.ShortenUrl;

@Service
public class ShortnerURLService {

	@Autowired
	ShortnerURLRepository shortnerURLRepository;
	
	 private static final String allowedString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	    private char[] allowedCharacters = allowedString.toCharArray();
	    private int base = allowedCharacters.length;

	   
	public String insertURLs(String longURL) {
		ShortenUrl shortenurl = new ShortenUrl();
		shortenurl.setLongUrl(longURL);
		ShortenUrl data = shortnerURLRepository.save(shortenurl);
		return encode(data.getId());
	}	
	
	public String getLongerURL(String shortURL) {		
		ShortenUrl shortenUrl = shortnerURLRepository.getLongerURL(decode(shortURL));
		return shortenUrl.getLongUrl();
	}
	
	 public String encode(long input){
	    	StringBuilder encodedString = new StringBuilder();
	        if(input == 0) {
	            return String.valueOf(allowedCharacters[0]);
	        }
	        while (input > 0) {
	            encodedString.append(allowedCharacters[(int) (input % base)]);
	            input = input / base;
	        }

	        return encodedString.reverse().toString();
	    }

	    public long decode(String input) {
	        char[] characters = input.toCharArray();
	        int length = characters.length;

	        int decoded = 0;

	        //counter is used to avoid reversing input string
	        int counter = 1;
	        for (int i = 0; i < length; i++) {
	            decoded += allowedString.indexOf(characters[i]) * Math.pow(base, length - counter);
	            counter++;
	        }
	        return decoded;
	    }
	

}
