package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.test.service.ShortnerURLService;

@RequestMapping({ "/rest/url" })
@RestController
public class ShortnerURLController {

	@Autowired
	private ShortnerURLService shortnerURLService;

	@PostMapping(value="/getShortUrl")
	public String getShortnerURL(String longURL) {
		shortnerURLService.insertURLs(longURL);
		return "shorterURL";
	}

	@PostMapping(value="/getLongōUrl")
	public String getLongerURL(String shortURL) {
		String longURL = shortnerURLService.getLongerURL(shortURL);
		return longURL;
	}

}