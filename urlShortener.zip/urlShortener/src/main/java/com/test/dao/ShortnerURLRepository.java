package com.test.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.test.model.ShortenUrl;

public interface ShortnerURLRepository extends  JpaRepository<ShortenUrl,Integer>{	
	
	@Query("SELECT ShortenUrl FROM Shortenurl su WHERE su.id:=id")
	ShortenUrl getLongerURL(long l);
	
	
}
